const data = require ("./src/config/config.json");
const axios = require('axios')

async function testDoppler() {
  try {
    
    const rspta = await axios.get(data.liga)
    console.log(rspta.data);

  } catch (error) {
    console.log('Error --',error)
  }
  
}

async function testMailDoppler() {
  try {    
    const liga = `${data.liga}/accounts/${data.accountId}/messages`
    const htmlData = `
      <h2 style="color: red;">Correo enviado desde nodejs</h2>

      <img src="./src/public/img/dasa.png"> </img>
    `

    const emailData = {
      from_name: 'Impulse',
      from_email: 'reportes@impulse-telecom.com',
      messageId: '1',
      subject: 'Correo desde nodejs',
      text: 'hola mundo',
      html: `${htmlData}`,
      headers: [
        {
          key: 'string',
          value: 'string'
        }
      ],
      deliveryGuids: [
        'string'
      ],
      
      reply_to: {
        email: 'danieluaeh@gmail.com',
        name: 'daniel'
      },
      recipients: [
        {
          email: 'dtrejo@impulse-telecom.com',
          name: 'Daniel 2',
          type: 'to'
        }
      ],
      skip_track_opens: true,
      skip_track_clicks: true,
      metadata: [
        {
          key: 'string',
          value: 'string'
        }
      ],
      sendingIPAddresses: [
        'string'
      ],
      priority: 'string'
    };
    const response = await axios.post(liga,emailData,{
      params : {api_key : data.apikey},
      headers : {'Content-Type': 'application/json'}
    })

    console.log(response.status)

  } catch (error) {
    console.log('Error --',error)
  }
  
}

// testDoppler ()

testMailDoppler ()




 














